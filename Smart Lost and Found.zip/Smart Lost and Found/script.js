const student = {
    name: "Anvi Jagtap",
    class: "V",
    division: "A",
    rollNo: "23",
    item: "School Bag"
    
};

document.getElementById("name").textContent = student.name;
document.getElementById("class").textContent = student.class;
document.getElementById("division").textContent = student.division;
document.getElementById("rollNo").textContent = student.rollNo;
document.getElementById("item").textContent = student.item;

document.querySelector("button").addEventListener("click", function () {
    alert("Thank you! The owner has been notified.");
});